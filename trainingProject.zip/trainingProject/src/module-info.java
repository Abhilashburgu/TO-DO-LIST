/**
 * 
 */
/**
 * @author abhil
 *
 */
module trainingProject {
}