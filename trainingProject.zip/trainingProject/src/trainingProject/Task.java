package trainingProject;

import java.util.Date;
public class Task {
	private String description;
    private boolean completed;
    private Date creationDate;
    private Date dueDate;

    public Task(String description,Date dueDate) {
        this.description = description;
        this.completed = false;
        this.creationDate = new Date();
        this.dueDate = dueDate;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void markAsCompleted() {
        completed = true;
    }

    public Date getCreationDate() {
        return creationDate;
    }
    public Date getDueDate() {
        return dueDate;
    }
    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }
    public void setDescription(String newDescription) {
        this.description = newDescription;
    }

}
