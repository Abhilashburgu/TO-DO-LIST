package trainingProject;

import java.util.List;
import java.util.ArrayList;

public class IoTDevice {
	 private String deviceName;
	    private List<String> tasks = new ArrayList<>();

	    public IoTDevice(String deviceName) {
	    	 this.deviceName = deviceName;
	    }

	    public void addTask(String task) {
	        tasks.add(task);
	    }

	    public List<String> getTasks() {
	        return tasks;
	    }

		public String getDeviceName() {
			return deviceName;
		}

		public void markTaskAsCompleted(int taskIndex) {
		    if (taskIndex >= 0 && taskIndex < tasks.size()) {
		        Task task = new Task(tasks.get(taskIndex), null); 
		        task.markAsCompleted();
		        tasks.set(taskIndex, task.getDescription()); 
		    }
		}
		public void updateTask(int taskIndex, String newDescription) {
	        if (taskIndex >= 0 && taskIndex < tasks.size()) {
	            tasks.set(taskIndex, newDescription);
	        }
	    }	

}
