package trainingProject;

import java.util.*;

public class CollaborativeToDoList {
	private Map<String, List<Task>> userTasks = new HashMap<>();

    public void addUser(String username) {
        userTasks.put(username, new ArrayList<>());
    }

    public void addTask(String username, String description, Date dueDate) {
        if (userTasks.containsKey(username)) {
            List<Task> tasks = userTasks.get(username);
            tasks.add(new Task(description, dueDate));
        }
    }


    public void showTasks(String username) {
        if (userTasks.containsKey(username)) {
            List<Task> tasks = userTasks.get(username);
            for (int i = 0; i < tasks.size(); i++) {
                Task task = tasks.get(i);
                String status = task.isCompleted() ? "Completed" : "Not Completed";
                System.out.println((i + 1) + ". " + task.getDescription() + " - " + status + " - Due: " + task.getDueDate());
            }
        }
    }

    public void markTaskAsCompleted(String username, int taskIndex) {
        if (userTasks.containsKey(username)) {
            List<Task> tasks = userTasks.get(username);
            if (taskIndex >= 0 && taskIndex < tasks.size()) {
                Task task = tasks.get(taskIndex);
                task.markAsCompleted();
            }
        }
    }
    public void updateTask(String username, int taskIndex, String newDescription) {
        if (userTasks.containsKey(username)) {
            List<Task> tasks = userTasks.get(username);
            if (taskIndex >= 0 && taskIndex < tasks.size()) {
                Task task = tasks.get(taskIndex);
                task.setDescription(newDescription);
            }
        }
    }

    public List<Task> getTasks(String username) {
        return userTasks.get(username);
    }

}
