package trainingProject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class IoTIntegratedToDoList {
	 public static void main(String[] args) {
	        CollaborativeToDoList collaborativeToDoList = new CollaborativeToDoList();
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter username for Collaborative To-Do List: ");
	        String username = scanner.nextLine();
	        collaborativeToDoList.addUser(username);

	        System.out.print("Enter device name for smart device: ");
	        String deviceName = scanner.nextLine();
	        IoTDevice iotDevice = new IoTDevice(deviceName);

	        while (true) {
	            
	        	System.out.println("\n1. Add Task to Collaborative List");
	        	System.out.println("2. Mark Task as Completed for Collaborative List");
	        	System.out.println("3. Show Your Tasks");
	        	System.out.println("4. Add Task to smart Device");
	        	System.out.println("5. Mark Task as Completed for smart Device");
	        	System.out.println("6. Show smart Device Tasks");
	        	System.out.println("7. Update Task Description");
	        	System.out.println("8. Exit");
	        	System.out.print("Select an option: ");

	            
	            
	            int choice = scanner.nextInt();
	            scanner.nextLine(); 
	            
	            if (choice == 1) {
	                
	            	 System.out.print("Enter task description: ");
	            	    String description = scanner.nextLine();
	            	    
	            	    System.out.print("Enter due date (yyyy-MM-dd HH:mm): ");
	            	    String dueDateString = scanner.nextLine();
	            	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	            	    Date dueDate;
	            	    try {
	            	        dueDate = dateFormat.parse(dueDateString);
	            	    } catch (ParseException e) {
	            	        System.out.println("Invalid date format. Task not added.");
	            	        break;
	            	    }

	            	    collaborativeToDoList.addTask(username, description, dueDate);
	            	    System.out.println("Task added to Collaborative List!");
	            	   
	            } else if (choice == 2) {
	                
	                System.out.print("Enter task index to mark as completed: ");
	                int taskIndex = scanner.nextInt() - 1;
	                scanner.nextLine(); 
	                collaborativeToDoList.markTaskAsCompleted(username, taskIndex);
	                System.out.println("Task marked as completed!");
	            } else if (choice == 3) {
	                
	                System.out.println("Your tasks:");
	                collaborativeToDoList.showTasks(username);
	            } else if (choice == 4) {
	                
	                System.out.print("Enter task description for smart Device: ");
	                String iotTask = scanner.nextLine();
	                iotDevice.addTask(iotTask);
	                System.out.println("Task added to smart Device!");
	            } else if (choice == 5) {
	               
	                System.out.println("Tasks from " + iotDevice.getDeviceName() + ":");
	                printIoTDeviceTasks(iotDevice);

	                System.out.print("Enter task index to mark as completed for IoT Device: ");
	                int taskIndex = scanner.nextInt() - 1;
	                scanner.nextLine(); 
	                iotDevice.markTaskAsCompleted(taskIndex);
	                System.out.println("Task marked as completed for smart Device!");
	            } else if (choice == 6) {
	                
	                System.out.println("Tasks from " + iotDevice.getDeviceName() + ":");
	                printIoTDeviceTasks(iotDevice);
	            } else if (choice == 7) {
	            	System.out.print("Enter task index to update: ");
	                int updateIndex = scanner.nextInt() - 1;
	                scanner.nextLine();

		                if (updateIndex >= 0 && updateIndex < collaborativeToDoList.getTasks(username).size()) {
		                    System.out.print("Enter new task description: ");
		                    String newDescription = scanner.nextLine();
		                    collaborativeToDoList.updateTask(username, updateIndex, newDescription);
		                    System.out.println("Task description updated!");
		                } 
		                
	                else if (choice == 8) {
	                    System.out.println("Thankyou for using TO-DO-LIST");
	                    return;
	                } 
	                
	               
	            } else {
	               
	                System.out.println("Invalid choice. Please choose a valid option.");
	            }
	        }

	       
	        System.out.println("Exiting the application.");
	        scanner.close();

	    }


	    private static void printIoTDeviceTasks(IoTDevice device) {
	        List<String> tasks = device.getTasks();
	        for (int i = 0; i < tasks.size(); i++) {
	            System.out.println((i + 1) + ". " + tasks.get(i));
	        }
	    }

}
